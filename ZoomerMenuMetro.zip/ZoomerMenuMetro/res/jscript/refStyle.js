/*

Copyright ?2012 Daniel Wiesen?cker



    

    This file is part of MatisseComponent.



    MatisseComponent is free software: you can redistribute it and/or modify

    it under the terms of the GNU General Public License as published by

    the Free Software Foundation, either version 3 of the License, or

    (at your option) any later version.



    MatisseComponent is distributed in the hope that it will be useful,

    but WITHOUT ANY WARRANTY; without even the implied warranty of

    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

    GNU General Public License for more details.



    You should have received a copy of the GNU General Public License

    along with MatisseComponent.  If not, see <http://www.gnu.org/licenses/>.



*/



var styleNameIncludeGetVar='style'; /*to be seteted by author*/



var found=urlGet(styleNameIncludeGetVar);

if(found!=-1){

	document.writeln("<link rel=\"styleSheet\" href=\"" + found + "\" type=\"text/css\">");

}


