function DebugNorrisArea(cols, rows, maxline, left, top){
	this.left=left?left:200;
	this.top=top?top:0;
	this.maxline=maxline?maxline:rows;
	this.rows=rows;
	this.cols=cols;
	this.id=-1;
	this.itsObj=null;
	this.cl=0;
	
	this.write=function(){
		var tmpId="dbGMsg" + Math.random()*100000 + Math.random()*10005;
		document.writeln("<DIV style=\"position: absolute; left: " + this.left + "px; top: " + this.top + "px; z-index:10000; \" ><TEXTAREA cols=\"" + this.cols + "\" rows=\"" + this.rows + "\" id=\"" + tmpId + "\" name=\"" + tmpId + "\" readonly></TEXTAREA></DIV>");
		this.id=tmpId;
		this.itsObj=document.getElementById&&false?document.getElementById(this.id):(document.getElementsByName(this.id).lenght>1?document.getElementsByName(this.id)[1]:document.getElementsByName(this.id)[0]);
	}
	
	this.out=function(str, nl){
		nl=nl?nl:false;
		if(this.cl>=this.maxline){
			this.cl=0;
			this.itsObj.value="";
		}
		this.itsObj.value+=str + (nl?"\n":"");
		this.itsObj.caretPos=this.itsObj.value.length-1;
		if(nl) this.cl++;
	}
	
	this.write();
}

var Dbg=new DebugNorrisArea(80, 21, 20, 0, 0);