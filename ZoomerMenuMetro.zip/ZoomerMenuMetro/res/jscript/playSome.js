/*
Copyright �2012 Daniel Wiesen�cker

    
    This file is part of MellowFire.

    MellowFire is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    MellowFire is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with MellowFire.  If not, see <http://www.gnu.org/licenses/>.

*/

	function Stadion(){

		this.execStack= null

		this.execLog=null;

		this.execlaunchByVarnameMillis=null;

		this.execDuration=null;



		this.addExecution = function(funcStr){

			if(this.execStack==null){

				this.execLog=new Array();

				this.execStack=new Array();

			}

			this.execStack.push(funcStr);
			this.execLog.push(false);

		}

		

		this.reset = function(){

			if(this.execLog!=null) for(var v=0; v < this.execLog.length; v++){

				this.execLog[v]=false;

			}

		}

		

		this.executeStack = function(){

			var tmpPrev= new Date();

			this.execlaunchByVarnameMillis=tmpPrev.getTime();

			for(var v=0; v < this.execStack.length; v++){

				if(!this.execLog[v]){

					if(this.execStack[v]){								
						eval(this.execStack[v]);
					}
					this.execLog[v]=true;
					
					}


			}

			var tmpAfter= new Date();

			this.execDuration=tmpAfter.getTime()-this.execlaunchByVarnameMillis;
		}

		

		this.length = function(){

			if(this.execStack==null){

				return null;

			}

			return this.execStack.length;

		}



		this.getExecutionTime = function(){

			return this.execlaunchByVarnameMillis;

		}



		this.getExecutionDuration = function(){

			return this.execDuration;

		}

	}



	function TimeLine(framecount){

		this.stadionAtFrame= new Array;

		for(var v=0; v < framecount; v++){

			this.stadionAtFrame[v]=new Stadion();

		}

	}



	function PlaySome(clipSelectionObj, fps, scrollYes, indexDrawYes, execute){
	
		this.c=0;



		this.indexDraw=indexDrawYes?indexDrawYes:false;



		this.fps=fps;



		this.clipSelectionObj=clipSelectionObj;
		
		
	


		this.timeLine = new TimeLine(this.clipSelectionObj.length);



		this.set=false



		this.thread= new Array();



		this.scrollYes=scrollYes?scrollYes:false;



		this.runs=false;



		this.from=0;



		this.to=this.clipSelectionObj.length;



		this.loop=false;



		this.lastSrc=null;

		execute=execute?execute:false;


		if(execute) this.setPlayerShutdownFunction(execute);



		

this.varName="";

	}



	function mute(what){

		for(var d=0; d < what.clipSelectionObj.length; d++){

			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.visibility='hidden';



		}

	}



	function seek(what){

		var check=getFirstClipIndexArray(what.clipSelectionObj);

		for(var r=0; r < check.length; r++){



		var d=check[r];	

			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.visibility='visible';

		}

	}



	function addFunctionAtFrame(frameNr, funcStr){

		this.timeLine.stadionAtFrame[frameNr].addExecution(funcStr);

	}



	

	PlaySome.prototype.addFunctionAtFrame = addFunctionAtFrame;





	function resetTimeLine(){

		if(this.timeLine.stadionAtFrame!=null) for(var v =0; v < this.timeLine.stadionAtFrame.length; v++){

			this.timeLine.stadionAtFrame[v].reset();

		}

	}

	

	PlaySome.prototype.resetTimeLine = resetTimeLine;





	function setPlayerShutdownFunction(to){

		this.addFunctionAtFrame(this.clipSelectionObj.length-1, to);

	}



	PlaySome.prototype.setPlayerShutdownFunction = setPlayerShutdownFunction;

	

	

function play(what, i){

		var firstFrame=false;

		if(what.c==what.from&&!what.set){

			var curTme=new Date();

			what.tmeRoll=what.tmeS=curTme.getTime();

			what.set=true;

			what.clipSelectionObj[0].itsPort.itsObject.itsStyle.visibility='visible';

			firstFrame=true;

		}else{

		

			var curTme=new Date();

			what.tmeRoll=curTme.getTime();

			



		}
		
		var a=what.c;

		var b=what.c;
		while((what.c<(what.to))&&(what.clipSelectionObj[what.c].millis<=(what.tmeRoll-what.tmeS))){

//very nec improovement on huge data mass

			if(what.runs) b=what.c++;

		}

		

		if(a<=what.to){

		

		for(var d=a; d <= b; d++){

			



		if(what.indexDraw){

	

			what.clipSelectionObj[d].itsPort.itsObject.indexPositioningStyle.visibility='visible';



			what.clipSelectionObj[d-1].itsPort.itsObject.indexPositioningStyle.visibility='hidden';



			

		}else{



		var changed=false;

	

			if(what.clipSelectionObj[d].hasImage){



				if(what.lastSrc!=null){

					changed=what.clipSelectionObj[d].itsPort.itsObject.itsImg.src!=what.lastSrc;

				}

				changed=firstFrame?true:changed;

				changed=what.clipSelectionObj[d].itsPort.itsObject.hasChanges==false?false:changed;

				if(changed) what.lastSrc=what.clipSelectionObj[d].itsPort.itsObject.itsImg.src;

			

			}

			if(!what.scrollYes){


			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.visibility=what.clipSelectionObj[d].visible?'visible':'hidden';





			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.left=what.clipSelectionObj[d].itsPort.getPoint().x;







			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.top=what.clipSelectionObj[d].itsPort.getPoint().y;



			



			if(what.clipSelectionObj[d].size.width) what.clipSelectionObj[d].itsPort.itsObject.itsStyle.width=what.clipSelectionObj[d].size.width;





			if(what.clipSelectionObj[d].size.height) what.clipSelectionObj[d].itsPort.itsObject.itsStyle.height=what.clipSelectionObj[d].size.height;

				if(what.clipSelectionObj[d].hasImage&&what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle!=null){

					what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.width=what.clipSelectionObj[d].size.width;

					what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.height=what.clipSelectionObj[d].size.height;

					if(changed){

						what.clipSelectionObj[d].itsPort.itsObject.itsImgObj.src=what.clipSelectionObj[d].itsPort.itsObject.itsImg.src;

					}

				}





			}else{

			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.visibility=what.clipSelectionObj[d].visible?"visible":"hidden";




			

			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.left=what.clipSelectionObj[d].itsPort.getPoint().x+document.body.scrollLeft;







			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.top=what.clipSelectionObj[d].itsPort.getPoint().y+document.body.scrollTop;







		what.clipSelectionObj[d].itsPort.itsObject.itsStyle.width=what.clipSelectionObj[d].size.width;





			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.height=what.clipSelectionObj[d].size.height;

		

				if(what.clipSelectionObj[d].hasImage&&what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle!=null){

					if(what.clipSelectionObj[d].size.width) what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.width=what.clipSelectionObj[d].size.width;

					if(what.clipSelectionObj[d].size.height) what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.height=what.clipSelectionObj[d].size.height;

					if(changed){

						what.clipSelectionObj[d].itsPort.itsObject.itsImgObj.src=what.clipSelectionObj[d].itsPort.itsObject.itsImg.src;

		

					}

;

				}

			}

			
			if(navigator.userAgent.toLowerCase().indexOf("netscape")!=-1){
				;//netscape does not support gamma or alpha opacity
			}
			else{
				setOpacity(what.clipSelectionObj[d].itsPort.itsObject.itsStyle, what.clipSelectionObj[d].alfaPercentage);	
				setTransform(what.clipSelectionObj[d].itsPort.itsObject.itsStyle, "transform: translate3d(0,0,0)");
			}
			
			if(what.timeLine) if(what.timeLine.stadionAtFrame) if(what.timeLine.stadionAtFrame[d]) if(what.timeLine.stadionAtFrame[d].length()>0){

				var tmp=setTimeout(what.varName  + ".timeLine.stadionAtFrame[" + d + "].executeStack();", 1);

				}





			}

		

		}

		}



			



		if((what.c>=(what.to))){

			if(!what.loop){

				

				what.runs=false;

				for(var b=0; b < what.thread.length; b++){

					clearInterval(what.thread[b]);

				}

				



			

			}else{

				if(what.indexDraw){

					what.clipSelectionObj[what.to-1].itsPort.itsObject.indexPositioningStyle.visibility='hidden';

				}

			}

			

			what.c=what.from;

			what.set=false;

			what.resetTimeLine();

	}

}


	function setDownByVarName(PlaySomeVarName, d){
		var what=null;

		what=eval(PlaySomeVarName);

		what.varName=PlaySomeVarName;
		
		displayFrame(what, d);
	}

	function reset(what){

		var check=getFirstClipIndexArray(what.clipSelectionObj);

for(var r=0; r < check.length; r++){



		var d=check[r];		

		if(!what.scrollYes){



			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.visibility=what.clipSelectionObj[d].visible?'visible':'hidden';





			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.left=what.clipSelectionObj[d].itsPort.getPoint().x;







			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.top=what.clipSelectionObj[d].itsPort.getPoint().y;







			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.width=what.clipSelectionObj[d].size.width;







			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.height=what.clipSelectionObj[d].size.height;







			if(what.clipSelectionObj[d].hasImage){

					what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.width=what.clipSelectionObj[d].size.width;

					what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.height=what.clipSelectionObj[d].size.height+ "px";

			}



		}else{

			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.visibility=what.clipSelectionObj[d].visible?"visible":"hidden";





			

			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.left=what.clipSelectionObj[d].itsPort.getPoint().x+document.body.scrollLeft;







			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.top=what.clipSelectionObj[d].itsPort.getPoint().y+document.body.scrollTop;







			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.width=what.clipSelectionObj[d].size.width;







			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.height=what.clipSelectionObj[d].size.height;





				if(what.clipSelectionObj[d].hasImage){

					what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.width=what.clipSelectionObj[d].size.width;

					what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.height=what.clipSelectionObj[d].size.height;

				}

		}

		
			if(navigator.userAgent.toLowerCase().indexOf("netscape")!=-1){
				;//netscape does not support gamma or alpha opacity
			}
			else{
				setOpacity(what.clipSelectionObj[d].itsPort.itsObject.itsStyle, what.clipSelectionObj[d].alfaPercentage);	
			}
	}

		

	

	}

	function displayFrame(what, f){
		var a=b=f;
		if(f==what.from) firstFrame=true;
		if(a<=what.to){

			

			for(var d=a; d <= b; d++){

			if(what.indexDraw){

		

				what.clipSelectionObj[d].itsPort.itsObject.indexPositioningStyle.visibility='visible';



				what.clipSelectionObj[d-1].itsPort.itsObject.indexPositioningStyle.visibility='hidden';



				

			}else{



			var changed=false;

		

				if(what.clipSelectionObj[d].hasImage){



					if(what.lastSrc!=null){

						changed=what.clipSelectionObj[d].itsPort.itsObject.itsImg.src!=what.lastSrc;

					}

					changed=firstFrame?true:changed;

					changed=what.clipSelectionObj[d].itsPort.itsObject.hasChanges==false?false:changed;

					if(changed) what.lastSrc=what.clipSelectionObj[d].itsPort.itsObject.itsImg.src;

				

				}

				if(!what.scrollYes){
				


				what.clipSelectionObj[d].itsPort.itsObject.itsStyle.visibility=what.clipSelectionObj[d].visible?'visible':'hidden';





				what.clipSelectionObj[d].itsPort.itsObject.itsStyle.left=what.clipSelectionObj[d].itsPort.getPoint().x;







				what.clipSelectionObj[d].itsPort.itsObject.itsStyle.top=what.clipSelectionObj[d].itsPort.getPoint().y;



				



				if(what.clipSelectionObj[d].size.width) what.clipSelectionObj[d].itsPort.itsObject.itsStyle.width=what.clipSelectionObj[d].size.width;





				if(what.clipSelectionObj[d].size.height) what.clipSelectionObj[d].itsPort.itsObject.itsStyle.height=what.clipSelectionObj[d].size.height;

					if(what.clipSelectionObj[d].hasImage&&what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle!=null){

						what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.width=what.clipSelectionObj[d].size.width;

						what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.height=what.clipSelectionObj[d].size.height;

						if(changed){

							what.clipSelectionObj[d].itsPort.itsObject.itsImgObj.src=what.clipSelectionObj[d].itsPort.itsObject.itsImg.src;

						}

					}





				}else{

				what.clipSelectionObj[d].itsPort.itsObject.itsStyle.visibility=what.clipSelectionObj[d].visible?"visible":"hidden";




				

				what.clipSelectionObj[d].itsPort.itsObject.itsStyle.left=what.clipSelectionObj[d].itsPort.getPoint().x+document.body.scrollLeft;







				what.clipSelectionObj[d].itsPort.itsObject.itsStyle.top=what.clipSelectionObj[d].itsPort.getPoint().y+document.body.scrollTop;







			what.clipSelectionObj[d].itsPort.itsObject.itsStyle.width=what.clipSelectionObj[d].size.width;





				what.clipSelectionObj[d].itsPort.itsObject.itsStyle.height=what.clipSelectionObj[d].size.height;

			

					if(what.clipSelectionObj[d].hasImage&&what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle!=null){

						if(what.clipSelectionObj[d].size.width) what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.width=what.clipSelectionObj[d].size.width;

						if(what.clipSelectionObj[d].size.height) what.clipSelectionObj[d].itsPort.itsObject.itsImgStyle.height=what.clipSelectionObj[d].size.height;

						if(changed){

							what.clipSelectionObj[d].itsPort.itsObject.itsImgObj.src=what.clipSelectionObj[d].itsPort.itsObject.itsImg.src;

			

						}
					;

					}

				}

				
					if(navigator.userAgent.toLowerCase().indexOf("netscape")!=-1){
						;//netscape does not support gamma or alpha opacity
					}
					else{
						setOpacity(what.clipSelectionObj[d].itsPort.itsObject.itsStyle, what.clipSelectionObj[d].alfaPercentage);	
					}
					if(what.timeLine) if(what.timeLine.stadionAtFrame) if(what.timeLine.stadionAtFrame[d]) if(what.timeLine.stadionAtFrame[d].length()>0){

						var tmp=setTimeout(what.varName  + ".timeLine.stadionAtFrame[" + d + "].executeStack();", 1);

					}





				}

			

			}

			}



				



			if((what.c>=(what.to))){

				what.c=what.from;

				what.set=false;

				what.resetTimeLine();

		}

	}

	function launchByVarname(PlaySomeVarName, threads, negate, from ,to, loop){

		
		
		var what=null;

		
		
		what=eval(PlaySomeVarName);
		
		what.varName=PlaySomeVarName;

		threads=threads?threads:(what.indexDraw?2:4); //ok.

		



		var millis=1000/what.fps;

		what.resetTimeLine();

		what.loop=loop?loop:false;

		what.set=false;

				for(var b=0; b < what.thread.length; b++){

					clearInterval(what.thread[b]);



				}

		what.c=from?from:(what.indexDraw?1:0);

		
		what.called=false;

		

what.from=what.c;
		what.to=to?to:what.clipSelectionObj.length;
		
		what.thread= new Array();

		for(var t=0; t< threads; t++){

			what.thread[what.thread.length]=setInterval('play(' + PlaySomeVarName + ', ' + t + ')', Math.round(millis/(t+1)));

		}

		what.runs=true;

		

	
		return !negate;
	}







	function start(PlaySomeVarName, threads, negate, from ,to, loop){
		return launchByVarname(PlaySomeVarName, threads, negate, from ,to, loop);
	}


