<?php
	header('Content-Type: text/html', true);
	header("Cache-Control: no-store, no-cache, must-revalidate");
	header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
	header("Pragma: no-cache");
?>
<?php
	error_reporting(E_ERROR);
	ini_set('display_errors', FALSE);
	//error_reporting(E_ALL);
	//ini_set('display_errors', TRUE);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HEAD>
<TITLE>
	ZoomerMenuMetro V. 1.809212.995b
</TITLE>
<script language="JavaScript" type="text/JavaScript" src="./res/jscript/nibblesNbytes.js">
</script>
<script language="JavaScript" type="text/JavaScript" src="./res/jscript/arrayFunctions.js">
</script>
<script language="JavaScript" type="text/JavaScript" src="./res/jscript/showNhide.js">
</script>
<script language="JavaScript" type="text/JavaScript" src="./res/jscript/trunkGeom.js">
</script>
<script language="JavaScript" type="text/JavaScript" src="./res/jscript/retainedZoom.js">
</script>
<script language="JavaScript" type="text/JavaScript" src="./res/jscript/cssGetta.js">
</script>
<script language="JavaScript" type="text/JavaScript" src="./res/jscript/playSome.js">
</script>
<script language="JavaScript" type="text/JavaScript" src="./res/jscript/tokenize.js">
</script>
<script language="JavaScript" type="text/JavaScript" src="./res/jscript/isNum.js">
</script>
<script language="JavaScript" type="text/JavaScript" src="./res/jscript/urlGet.js">
</script>
<script language="JavaScript" type="text/JavaScript">
<?php
	require_once("./menuDefineItems.php");
?>
</script>
<script language="JavaScript" type="text/JavaScript">
	var thread=null;

	var over = new Array();



	for(var v=0; v < MainCategories.length*2; v++){

		over[v]=false;

	}



/*
	function getStick(relRootStr, catId){



		var relRoot=eval(relRootStr);

		for(var v=0; v < relRoot.length; v++){

			var ele=false;

			var nrelstr=relRootStr + "[" + v + "][9]";

			try{

				ele=eval(nrelstr);

			}catch(e){

				ele=false;

			}finally{

				if(ele){

					var buf=getStick(nrelstr, catId);

					if(buf==0){

						;

					}else{



						return buf;

					}

				}if(relRoot[v][5]==catId&&relRoot[v][5]!='0'){

					nrelstr=relRootStr + "[" + v + "]";



					return eval(nrelstr);

				}

			}

		}

		return 0; //when lenght =0	

	}







	function getStickStr(relRootStr, catId){



		var relRoot=eval(relRootStr);

		for(var v=0; v < relRoot.length; v++){

			var ele=false;

			var nrelstr=relRootStr + "[" + v + "][9]";

			try{

				ele=eval(nrelstr);

			}catch(e){

				ele=false;

			}finally{

				if(ele){

					var buf=getStick(nrelstr, catId);

					if(buf==0){

						;

					}else{



						return buf;

					}

				}if(relRoot[v][5]==catId&&relRoot[v][5]!='0'){

					nrelstr=relRootStr + "[" + v + "]";



					return nrelstr;

				}

			}

		}

		return 0; //when lenght =0	

	}


*/
	
	function setOverState(numP, to){

		for(var s=0; s < over.length; s++){
			over[s]=false;
		}
		over[numP]=to;
		
	}



	function setOutState(numP, to){
		over[numP]=to;
	}

	function getState(numP){		
		return(over[numP]);	
	}

</SCRIPT>



</HEAD>

<BODY style="margin: 0px; background-color: #33FFCC; " onload="">

<SCRIPT language="JavaScript" type="text/JavaScript">
var itsSelection=new Animation();
var fps=60;
var threads=4;
var letterWidth=7;
var spaceBuffer=40;
MenuWidth=0;
borderSpacer=3;

function ZoomerMenuMetro(MenuLeft, top, height, menuItems, fontSize, spacer, zoomByPixels, fontPath, fontColor, backgroundColor, backgroundImage, backgroundImageLeftKick, backgroundImageRightKick, spaceBuffer){

	var _height=height;
	var _fontSize=fontSize;
	var _spacer=spacer;
	var _fontColorRed=hex2int(fontColor.substr(1,2));
	var _fontColorGreen=hex2int(fontColor.substr(3,2));
	var _fontColorBlue=hex2int(fontColor.substr(5,2));
	var _backColorRed=hex2int(backgroundColor.substr(1,2));
	var _backColorGreen=hex2int(backgroundColor.substr(3,2));
	var _backColorBlue=hex2int(backgroundColor.substr(5,2));
	var _fontPath=fontPath;


	zoomer = new Array();

	player = new Array();
	
	var itsWidth=new Array();
	
	var itsHeight=new Array();
	
	<?php
	$buttons=$items;
	$count=0;
	for($v=0; $v < sizeof($buttons); $v++){
			$stdpath="./produce/";
			$thatFile=$stdpath . "fxd_" . $buttons[$count] . ".gif";
			//echo $thatFile;
			if(file_exists($thatFile)){
				$ButtonImg = ImageCreateFromGIF($thatFile);
				echo "itsWidth[" . $count . "]=" . imagesx($ButtonImg) . ";\n";
				echo "itsHeight[" . $count . "]=" . imagesy($ButtonImg) . ";\n";
			}else{
				echo "itsWidth[" . $count . "]=0;\n";
				echo "itsHeight[" . $count . "]=0;\n";
			}
			$count++;
	}
	?>
	for(var v=0; v < MainCategories.length; v++){

		var str=MainCategories[v][1];
		menuItems[v][6] = new Image(); 
		menuItems[v][6].src = "./getStringAsImage.php?isString=" + escape(str) + "&fontSize=" + _fontSize + "&spacer=" + _spacer + "&height=" + _height + "&fontColorRed=" + _fontColorRed + "&fontColorGreen=" + _fontColorGreen + "&fontColorBlue=" + _fontColorBlue + "&backColorRed=" + _backColorRed + "&backColorGreen=" + _backColorGreen + "&backColorBlue=" + _backColorBlue + "&fontPath=" + escape(_fontPath) + "&hcenter=true&vcenter=true&backImage=" + backgroundImage + "&backImageLeftKick=" + backgroundImageLeftKick + "&backImageRightKick=" + backgroundImageRightKick;
		var height=itsHeight[v];
		var width=itsWidth[v];
		clipnameUp = "Clip" + v;
		clipnameDown = "Clip_down" + v;
		var upI=zoomer.length;
		var downI=zoomer.length+1;
		document.writeln("<DIV id=\"" + MainCategories[v][5] + "\" onmouseout=\"if(!getState(" + downI + ")&&!player[" + downI + "].runs&&!player[" + upI + "].runs) setOutState(" + downI + ", launchByVarname('player[" + downI + "]', " + threads + ", true));\" onmouseover=\"if(!getState(" + upI + ")&&!player[" + downI + "].runs&&!player[" + upI + "].runs) setOverState(" + upI + ", launchByVarname('player[" + upI + "]', " + threads + ", true));\" style=\"position: absolute; top: " + top + "; left: " + MenuLeft + "; width: " + width + "px; height: " + height + "; z-index: 4; \">");
		document.writeln("<A style=\"\" href=\"" + MainCategories[v][2] + "\">");		
		document.writeln("<SPAN>");
		document.writeln("<IMG style=\"border-style: none; width: " + width + "px; height: " + height + ";\" name=\"" + menuItems[v][5] + "\" src=\"" + menuItems[v][6].src + "\" alt=\"" + menuItems[v][1] + "\"></IMG>");
		document.writeln("</SPAN>");
		document.writeln("</A>");
		document.writeln("</DIV>");
		itsSelection.addClip(clipnameUp, MenuLeft, top, menuItems[v][6].src, width, height, "javascript:", CENTER, MIDDLE, menuItems[v][5])
		itsSelection.addClip(clipnameDown, MenuLeft - zoomByPixels/2, top-zoomByPixels/2, menuItems[v][6].src, width+zoomByPixels, height+zoomByPixels, "javascript:", CENTER, MIDDLE, menuItems[v][5]);
		zoomer[upI]=new Zoom(itsSelection, itsSelection.getClipsByName(clipnameUp)[0].id, 0, 0, zoomByPixels, zoomByPixels, 0, 0, 100, fps,  false, menuItems[v][5]);
		zoomer[downI]=new Zoom(itsSelection, itsSelection.getClipsByName(clipnameDown)[0].id, 0, 0, -zoomByPixels, -zoomByPixels, 0, 0, 100, fps, false, menuItems[v][5]);
		itsSelection.defineObjectBinding(clipnameUp, MainCategories[v][5]);
		itsSelection.defineObjectBinding(clipnameDown, MainCategories[v][5]);
		
		player[upI] = new PlaySome(itsSelection.getClipsByName(clipnameUp), fps, false, false);
		player[downI] = new PlaySome(itsSelection.getClipsByName(clipnameDown), fps, false, false);
		MenuLeft+=width+spaceBuffer;

		}

}

var itsZoomerMenuMetro = new ZoomerMenuMetro(220, 210, 50, MainCategories, 20, 28, 60, "./res/fonts/verdana.ttf", "#000000", "#DD11FF", "./res/Blue.gif", "./res/BlueLeft.gif", "./res/BlueRight.gif", 45);
</SCRIPT>
</BODY>
</HTML>