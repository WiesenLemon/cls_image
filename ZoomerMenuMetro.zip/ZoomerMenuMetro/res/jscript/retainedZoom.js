/*
Copyright �2012 Daniel Wiesen�cker

    
    This file is part of MellowFire.

    MellowFire is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    MellowFire is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with MellowFire.  If not, see <http://www.gnu.org/licenses/>.

*/
//**************************************************
//V_ALIGN and H_ALIGN FIELDSET
//<BETA> 
/*
deprecated
*/
	var LAYOUT=6;
	var CENTER=0;
	var MIDDLE=1;
	var LEFT=2;
	var RIGHT=3;
	var TOP=4;
	var BOTTOM=5;
	var KEEP=6;
//Animation MODE FLAGs
/*
deprecated
*/
	var REPOS=0;
	var REINDEX=1;  // almost every browser does fine
//**************************************************
	function AniMode(i, rsstatic){
		this.isReIndex=false;
		this.isRePos=false;
		this.isReIndex=i==AniMode.prototype.REPPOS?false:(AniMode.prototype.REINDEX?true:false);
		this.isRePos=i==AniMode.prototype.REINDEX?false:(AniMode.prototype.REPOS?true:false);
		if(!rsstatic) if(!this.isReIndex&&!this.isRePos) this.isOverflow=true;

		this.setAniMode=function(to){
			var tmp=new AniMode(to);
			this.isReIndex=tmp.isReIndex;
			this.isRePos=tmp.isRePos;
			if(!this.isReIndex&&!this.isRePos) this.isOverflow=true;
		}

		this.setCustom=function(to){
			this.isCustom=to?to:false;
		}
	}
	AnimationMode = new AniMode(null, true);
	AniMode.prototype.REPOS=0;
	AniMode.prototype.REINDEX=1;
	AniMode.prototype.CUSTOM=2; //reserved for further implementation
	AniMode.prototype.OVERFLOW=3;

	function Align(direction){
		this.dir=direction?direction:null;
		this.getAlign=function(){
			return this.dir!=null?this.dir:AlignSet.KEEP;
		}
	}

	Align.prototype.CENTER=0;
	Align.prototype.MIDDLE=1;
	Align.prototype.LEFT=2;
	Align.prototype.RIGHT=3;
	Align.prototype.TOP=4;
	Align.prototype.BOTTOM=5;
	Align.prototype.KEEP=6;

	AlignSet = new Align();
	function Flag(type){
		type=type?type:Flag.prototype.STATIC;
		this.rail=type;
	}

	Flag.prototype.DECELERATED=0;
	Flag.prototype.ACCELERATED=1;
	Flag.prototype.DUPLICATE=3;
	Flag.prototype.SORTED=4;
	Flag.prototype=DESORTED=5;
	Flag.prototype=KEYFRAME=6;
	Flag.prototype.STATIC=7;
	

	FlagRegister = new Flag();

	function FlagHolder(){
		this.holder=new ArrayList;
		this.setFlag = function(flag){
			this.holder.push(flag);
		}
		this.removeFlag=function(flag){
			var found=this.holder.find(flag);
			if(found) this.remove(found);
		}
		this.isSet=function(flag){
			return (this.holder.find(flag)>=0);
		}
	}

	function Animation(){
		Array.call(this);
		ArrayList.call(this);
	}

	if(document.all) Animation = Array;
	Animation.prototype = new Array();
	Animation.prototype = new ArrayList();
	Animation.prototype.constructor = Animation;

	
	//14XA134445
	function Animation_grabClipById(name, id, href, halign, valign, tmeOffsetMillis, dstArray){
		var itsImage=null;
		var itsStyle=null;
		var obj=document.getElementById(id);
		var se=obj;
		var st=obj;
		
		while(obj.nodeName!="DIV"){
			obj=obj.firstChild;
		}
		itsStyle=obj.style;
		se=se.firstChild.nextSibling;
		itsImage=se;
		imgsrc=se.src?se.src:"";
		var index=-1;
		if(this.getClipsByName(name)!=null){
			index=this.getClipsByName(name)[0].id;
		}else{
			index=this.length;
		}
		var nil=createClip(this, name, index, parseInt(itsStyle.left), parseInt(itsStyle.top), imgsrc, parseInt(itsImage.style.width),  parseInt(itsImage.style.height), href, halign, valign, obj.id, tmeOffsetMillis, dstArray);
		if(nil!=null) this.push(nil);
	}
	
	function Animation_grabClipByObj(name, obj, href, halign, valign, tmeOffsetMillis, dstArray){
		var itsImage=null;
		var itsStyle=null;
		var se=obj;
		var st=obj;
		while(obj.nodeName!="DIV"){
			obj=obj.firstChild;
		}
		itsStyle=obj.style;
		se=se.firstChild.nextSibling;
		itsImage=se;
		imgsrc=se.src?se.src:"";
		
		var index=-1;
		if(this.getClipsByName(name)){
			index=this.getClipsByName(name)[0].id;
		}else{
			index=this.length;
		}
		var nil=createClip(this, name, index, parseInt(itsStyle.left), parseInt(itsStyle.top), imgsrc, parseInt(itsStyle.width),  parseInt(itsStyle.height), href, halign, valign, obj.id, tmeOffsetMillis, dstArray);
		if(nil!=null) this.push(nil);	//5kkk
	}


	function Animation_addClip(name, setX, setY, imgsrc, width, height, href, halign, valign, id, tmeOffsetMillis, dstArray){
		dstArray=dstArray?dstArray:false;
		var index=-1;
		if(this.getClipsByName(name)!=null){
			index=this.getClipsByName(name)[0].id;
		}else{
			index=this.length;
		}
		var nil=createClip(this, name, index, setX, setY, imgsrc, width, height, href, halign, valign, id, tmeOffsetMillis, dstArray);
		if(nil!=null) this.push(nil);	//5kkk
	}

	
	/*works fine FORCA*/
	//****
	function Animation_appendClip(name, imgsrc, width, height, href, halign, valign, id, tmeOffsetMillis, dstArray){
		var index=-1;
		if(this.getClipsByName(name)){
			index=this.getClipsByName(name)[0].id;
		}else{
			index=this.length;
		}
		var setX=-1;
		var setY=-1;
		if(halign==AlignSet.CENTER){
				setX=this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getPoint().x+Math.round((parseInt(this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getSize().getWidth())-width)/2);
			}else if(halign==AlignSet.LEFT){
				setX=this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getPoint().x;
			}else if(halign==AlignSet.RIGHT){
				setX=this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getPoint().x+Math.round((parseInt(this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getSize().getWidth())-width));
			}else if(halign=AlignSet.KEEP){
				setX=this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getPoint().x;
			}
			if(valign==AlignSet.MIDDLE){
				setY=this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getPoint().y+Math.round((parseInt(this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getSize().getHeight())-height)/2);
			}else if(valign==AlignSet.TOP){
				setY=this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getPoint().y;
			}else if(valign=AlignSet.BOTTOM){
				setY=this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getPoint().y+Math.round((parseInt(this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getSize().getHeight())-height));
			}else if(valign=AlignSet.KEEP){
				setY=this.getClipsByName(name)[this.getClipsByName(name).length-1].itsPort.getPoint().y;
			}
			this.push(createClip(this, name, index, setX, setY, imgsrc, width, height, href, halign, valign, id, tmeOffsetMillis, dstArray));
		}
	//****

	function Animation_addClipFrom(name, clip, halign, valign, dstArray){//2btt crsdarsda
		var indicator=this.getClipsByName(name)[0].id;
		index=indicator>=0?indicator:this.length;
		this.push(createClip(this, name, index, clip[clip.length-1].itsPort.getPoint().x, clip[clip.length-1].itsPort.getPoint().y, clip[clip.length-1].itsPort.getObject().itsImg.src, clip[clip.length-1].size.width, clip[clip.length-1].size.height, clip[clip.length-1].href, halign, valign, false, clip[clip.length-1].millis, dstArray));
	}

	function Animation_getIdWith(name){
		var found=-1;
		var count=0;
		while(found<0&&count<this.length){
				if(this[count]!=null) found=this[count][0].name==name?count:found; //search for nil and moonraker atB
			count++;
		}
		return found;
	}

	function Animation_getClipsByName(name){
		var f=this.getIdWith(name);
		if(this.length>0){
			return (f!=-1?this[f]:null);
		}
		return null;
	}

	Animation.prototype.addClip=Animation_addClip;
	Animation.prototype.grabClipById=Animation_grabClipById;
	Animation.prototype.grabClipByObj=Animation_grabClipByObj;
	Animation.prototype.appendClip=Animation_appendClip;
	Animation.prototype.addClipFrom=Animation_addClipFrom;
	Animation.prototype.getClipsByName=Animation_getClipsByName;
	Animation.prototype.getIdWith=Animation_getIdWith;

	function getFirstClipIndexArray(ofThese){
		var firstName="";
		var lastStockedName=""
		var result=new Array();
		var count=0;
		var reached=false;
		for(var v=0; (v < ofThese.length) && (!reached); v++){
			var override=false;
			if(firstName==""){
				firstName=ofThese[v].name;
				lastStockedName=ofThese[v].name;
				result[count++]=v;
				override=true;
			}
			if(lastStockedName!=ofThese[v].name){
				lastStockedName=ofThese[v].name;
			}
			if(!override) if(lastStockedName==firstName){
				reached=true;	
			}else{
				result[count++]=v;
			}
		}
		return result;
	}

	function ExtPortObject(imgsrc, id){
		this.itsStyle=null;
		this.itsImgStyle=null;
		this.itsImgObj=null;
		this.hasChanges=true;
		this.itsImg= new Image();
		this.itsImg.src=imgsrc;
		if(imgsrc=="") this.hasChanges=false;
		this.id=id;
		this.indexPositioningStyle=null;
		this.indexPositioningId=id;
	}
//older netscape specific code
//*****************
	function getLayerObject(obj, id){
		var layers=obj.layers;
		var found=-1;
		for(var r=0; r < layers.length&&found==-1; r++){
			found=layers[r].id==id?r:found;
		}
		var retval=found>=0?layers[found]:null;
		return retval;
	}
	
	function getImageObject(obj, imgname){
		var images=obj.images;
		var found=-1;
		for(var v=0; v < images.length&&found==-1; v++){
			found=images[v].name==imgname?v:found;
		}
		var retval=found>=0?images[found]:null; 
		return retval;
	}
//^^^^^^^^^^^^^^^^^^^^^^^^^^
//**************************
	function Animation_defineObjectBinding(name, id){
		var tempClip=this.getClipsByName(name);
		var style=null;
		if(document.layers){
			style=getLayerObject(document, id);
		}else if(document.getElementById){
			if(document.getElementById(id).style){
				style=document.getElementById(id).style;
			}
		}else if(document.getElementsByName){
			style=document.getElementsByName(id)[(document.getElementsByName(id).length==3?1:0)].style;
		
		}
		var img=null;
		var hasImage=true;
		if(document.layers){
			img=getImageObject(document, id);
		}else if(document.getElementsByName(id).length>=1&&document.getElementsByName(id)[(document.getElementsByName(id).length==2?1:0)].nodeName=="IMG"){
			img=document.getElementsByName(id)[(document.getElementsByName(id).length==2?1:0)];
		}else{
			hasImage=false;
		}
		for(var v=0; v< tempClip.length; v++){
			tempClip[v].hasImage=hasImage;
			tempClip[v].itsPort.getObject().id=id;
			tempClip[v].itsPort.getObject().itsStyle=style;
			if(tempClip[v].valign==LAYOUT&&tempClip[v].halign==LAYOUT){		
				;
			}else{
			if(tempClip[0].itsPort.getPoint().x==-1) tempClip[v].itsPort.getPoint().x=style?parseInt(style.left):0;
			if(tempClip[0].itsPort.getPoint().y==-1) tempClip[v].itsPort.getPoint().setY(style?parseInt(style.top):0);
			if(tempClip[0].width==-1) tempClip[v].width=parseInt(style.width);
			if(tempClip[0].height==-1) tempClip[v].height=parseInt(style.height);
			if((tempClip[0].width==-1)||(tempClip[0].height==-1)) tempClip[v].size = new Dimension(tempClip[v].width, tempClip[v].height);
}			
			if(tempClip[0].animMode==REINDEX){
				if(v>=1){
					tempClip[v].itsPort.getObject().indexPositioningStyle=document.getElementById(tempClip[v].itsPort.getObject().indexPositioningId).style;
				}else{
					tempClip[v].itsPort.getObject().indexPositioningStyle=style;
				}
			}
			if((document.layers?img:(img?img.style:false))){
				tempClip[v].itsPort.getObject().itsImgStyle=document.layers?img:(img?img.style:null);
			}else{
				tempClip[v].hasImage=false;				
			}
			if(hasImage&&(!tempClip[v].itsPort.getObject().itsImgObj)) tempClip[v].itsPort.getObject().itsImgObj=img;
		}
	}

	Animation.prototype.defineObjectBinding=Animation_defineObjectBinding;

	function Animation_free(name){
		var tempClip=this.getClipsByName(name);
		if(tempClip) for(var v=0; v< tempClip.length; v++){
			tempClip[v].hasImage=null;
			tempClip[v].itsPort.getObject().id=null;
			tempClip[v].itsPort.getObject().itsStyle=null;
			tempClip[v].itsPort.getObject().itsImgObj=null;
			tempClip[v].itsPort.getObject().itsImgStyle=null;
			tempClip[v].itsPort.itsObject=null;
			tempClip[v].itsPort=null;
		}
	}

	Animation.prototype.free=Animation_free;
	Animation.prototype.copy=copy;


	function createClip(selection, name, index, setX, setY, imgsrc, width, height, href, halign, valign, id, tmeOffsetMillis, dstArray){
		dstArray?dstArray:false;
		var found=-1;
		var count=0;
		while(found<0&&count<selection.length){
			found=index==count?count:found;
			count++;
		}
		if(found>=0){
			selection[found].push(createDataFish(selection, name, found, setX, setY, imgsrc, width, height, href, halign, valign, id, tmeOffsetMillis, dstArray, imgsrc!=""?true:false));
			return null;
		}else{
			var generatedSelection=new Animation();
			generatedSelection.push(createDataFish(selection, name, selection.length, setX, setY, imgsrc, width, height, href, halign, valign, id, tmeOffsetMillis, dstArray, imgsrc!=""?true:false));
			
			return generatedSelection;
		}
	}

	function Port(obj1, rect){
		this.itsRectangle = rect;
		this.itsObject = obj1;

		this.getObject = function(){
			return this.itsObject;
		}
		this.getRectangle = function(){
			return this.itsRectangle;
		}
		this.getPoint = function(){
			return this.getRectangle().getPoint();
		}
		this.getSize = function(){
			return this.getRectangle().getSize();
		}
	}

	function createDataFish(selection, name, index, setX, setY, imgsrc, width, height, href, halign, valign, id, tmeOffsetMillis, dstArray, hasImage){
		dstArray=dstArray?dstArray:false;
		var tempPoint = new Point(setX, setY);
		var tempPort = new Port(new ExtPortObject(imgsrc, id), new Rectangle(tempPoint, new Dimension(width, height)));
		var dataFishes = new Animation;
		var i=-1;
		if(!dstArray){
			dstArray=dataFishes;
		}else{
			;
		}
		i=dstArray.length;
		dstArray.push(new balancedRetainedDataFish(selection, name, index, i, tempPort, width, height, href, halign, valign, id, tmeOffsetMillis, hasImage));
		return dstArray[dstArray.length-1];
	}
	//<BALANCED_RETAINED_DATA_FISH>

	function balancedRetainedDataFish(selection, name, id, i, port, width, height, href, halign, valign, sid, tmeOffsetMillis, hi){
		this.itsFlags = new FlagHolder();
		this.parent=selection;
		this.visible=true;
		this.href=href;
		this.name=name;
		this.i=i;
		this.id=id;
		tmeOffsetMillis?tmeOffsetMillis:false;
		this.millis = tmeOffsetMillis?tmeOffsetMillis:0;
		this.itsPort = port;
		this.alfaPercentage=99;
		this.animMode=0;
		width=width||width==-1?width:0;//XX
		height=height||height==-1?height:0;//XX
		this.itsPort.getObject().id=sid;
		this.size = new Dimension(width>=0?width:0, height>=0?height:0);
		this.halign=halign;
		this.valign=valign;
		this.hasImage=hi;
		if(sid){
			if(document.layers){
				this.itsPort.getObject().itsStyle=getLayerObject(document, sid).style;
			}else if(document.getElementById){
					if(document.getElementById(sid)){
						this.itsPort.getObject().itsStyle=document.getElementById(sid).style;
				}
			}else{
				this.itsPort.getObject().itsStyle=document.getElementsByName(sid)[(document.getElementsByName(sid).length==3?1:0)].style;
			}
			
		}
		if(document.layers){
			var tmpObj=getImageObject(document, id);
			this.itsPort.getObject().itsImgStyle=tmpObj;
		}else if(document.getElementsByName) if(document.getElementsByName(id).length>=2&&document.getElementsByName(id)[(document.getElementsByName(id).length==3?2:1)].nodeName=="IMG"){
			this.itsPort.getObject().itsImgStyle=document.getElementsByName(sid)[(document.getElementsByName(id).length==3?2:1)].style;
		}
	}

	function duplicateClip(clipName, index, dstArray, offset, offsetAbs){
		var do_offset=offset?this.getClipsByName(clipName)[index].millis+offset:(offsetAbs?offsetAbs:this.getClipsByName(clipName)[index].millis);
		this[this.getIdWith(clipName)].push(createDataFish(this, this.getClipsByName(clipName)[index].name, this[this.getIdWith(clipName)][index].id, this[this.getIdWith(clipName)][index].itsPort.getPoint().x, this[this.getIdWith(clipName)][index].itsPort.getPoint().y, this[this.getIdWith(clipName)][index].itsPort.getObject().itsImg.src, this[this.getIdWith(clipName)][index].size.width, this[this.getIdWith(clipName)][index].size.height, this[this.getIdWith(clipName)][index].href, this[this.getIdWith(clipName)][index].halign, this[this.getIdWith(clipName)][index].valign, this[this.getIdWith(clipName)][index].itsPort.getObject().id, do_offset, dstArray, this[this.getIdWith(clipName)][index].hasImage));
	}

	function duplicateLastClip(clipName, dstArray, offset, offsetAbs){
		this.duplicate(clipName, this.getClipsByName(clipName).length-1, dstArray, offset, offsetAbs);
	}

	Animation.prototype.duplicate = duplicateClip;
	Animation.prototype.duplicateLast = duplicateLastClip;

	function balancedRetainedDataFish_setflowAniMode(to){
		if(to==REINDEX) this.setAnimationMode(AnimationMode.REINDEX);
		if(to==REPOS) this.setAnimationMode(AnimationMode.REPOS);
	}

	function balancedRetainedDataFish_setAnimationMode(to){
		this.animMode=to;
	}

	function balancedRetainedDataFish_getHTML(zindex, linkTarget, clickEvent, doubleClickEvent, LayerInnerHTML, itsStyleA, mouseOutEvent, mouseInEvent, alt, span, vis){
		span=span?span:false;
		LayerInnerHTML=LayerInnerHTML?LayerInnerHTML:"";
		doubleClickEvent=doubleClickEvent?doubleClickEvent:"";
		clickEvent=clickEvent?clickEvent:"";
		mouseOutEvent=mouseOutEvent?mouseOutEvent:"";
		mouseInEvent=mouseInEvent?mouseInEvent:"";
		alt=alt?alt:"";
		linkTarget=linkTarget?linkTarget:"_self";

		return "<" + (span?"span":(document.layers?"div":"div")) + " name=\"" + this.name + "\" id=\"" + this.name + "\" onmouseover=\"" + mouseInEvent + "\" onmouseout=\"" + mouseOutEvent + "\" onclick=\"" + clickEvent + "\" ondblclick=\"" + doubleClickEvent + "\" style=\"" + (itsStyleA?itsStyleA:"") + "opacity: " + (this.alfaPercentage>=100?"1." + this.alfaPercentage-100:"0." + this.alfaPercentage) + "; " + (this.itsPort.getPoint().x!=-1?("position: absolute; left: " + Math.floor(this.itsPort.getPoint().x) + "px; top: " + Math.floor(this.itsPort.getPoint().y) + "px; "):"") +  "width: " + Math.floor(this.size.width) + "; height: " + Math.floor(this.size.height) + "; visibility: " + (vis?SHOW:HIDE) + "; z-index: " + (zindex?zindex:0) + "; \">" + (this.href!=""?("<a href=\"" + this.href + "\" target=\"" + linkTarget + "\">"):"") + (LayerInnerHTML!=""?LayerInnerHTML:"") + (this.hasImage?("<img name=\"" + this.name + "\" src=\"" + this.itsPort.getObject().itsImg.src + "\" alt=\"" + alt + "\" style=\"border-style: none; border-width: 0px; width: " + this.size.width + "px; height: " + this.size.height + "px; \">"):"") + (this.href!=""?"</a>":"") + "</" + (span?"span":(document.layers?"div":"div")) + ">";
	}

	function balancedRetainedDataFish_write(zindex, linkTarget, clickEvent, doubleClickEvent, LayerInnerHTML, itsStyleA, mouseOutEvent, mouseInEvent, alt, span, vis){
		span=span?span:false;
		LayerInnerHTML=LayerInnerHTML?LayerInnerHTML:"";
		doubleClickEvent=doubleClickEvent?doubleClickEvent:"";
		clickEvent=clickEvent?clickEvent:"";
		mouseOutEvent=mouseOutEvent?mouseOutEvent:"";
		mouseInEvent=mouseInEvent?mouseInEvent:"";
		alt=alt?alt:"";
		linkTarget=linkTarget?linkTarget:"_self";
		document.write("<" + (span?"span":(document.layers?"div":"div")) + " name=\"" + this.name + "\" id=\"" + this.name + "\" onmouseover=\"" + mouseInEvent + "\" onmouseout=\"" + mouseOutEvent + "\" onclick=\"" + clickEvent + "\" ondblclick=\"" + doubleClickEvent + "\" style=\"" + (itsStyleA?itsStyleA:"") + "opacity: " + (this.alfaPercentage>=100?"1." + this.alfaPercentage-100:"0." + this.alfaPercentage) + "; " + (this.itsPort.getPoint().x!=-1?("position: absolute; left: " + Math.floor(this.itsPort.getPoint().x) + "px; top: " + Math.floor(this.itsPort.getPoint().y) + "px; "):"") +  "width: " + Math.floor(this.size.width) + "; height: " + Math.floor(this.size.height) + "; visibility: " + (vis?SHOW:HIDE) + "; z-index: " + (zindex?zindex:0) + "; \">" + (this.href!=""?("<a href=\"" + this.href + "\" target=\"" + linkTarget + "\">"):"") + (LayerInnerHTML!=""?LayerInnerHTML:"") + (this.hasImage?("<img name=\"" + this.name + "\" src=\"" + this.itsPort.getObject().itsImg.src + "\" alt=\"" + alt + "\" title=\"" + alt + "\" style=\"border-style: none; border-width: 0px; width: " + this.size.width + "px; height: " + this.size.height + "px; \">"):"") + (this.href!=""?"</a>":"") + "</" + (span?"span":(document.layers?"div":"div")) + ">");
		if(this.animMode==AnimationMode.REINDEX){
			var selName=this.name;
			for(var v=1; v < this.parent.getClipsByName(selName).length; v++){
				document.write("<" + (span?"span":(document.layers?"div":"div")) + " name=\"" + this.parent.getClipsByName(selName)[v].itsPort.getObject().indexPositioningId + "\" id=\"" + this.parent.getClipsByName(selName)[v].itsPort.getObject().indexPositioningId + "\" onmouseover=\"" + mouseInEvent + "\" onmouseout=\"" + mouseOutEvent + "\" onclick=\"" + clickEvent + "\" ondblclick=\"" + doubleClickEvent + "\" style=\"" + (itsStyleA?itsStyleA:"") + "opacity: " + (this.alfaPercentage>=100?"1." + this.parent.getClipsByName(selName)[v].alfaPercentage-100:"0." + this.parent.getClipsByName(selName)[v].alfaPercentage) + "; " + (this.parent.getClipsByName(selName)[v].itsPort.getPoint().x!=-1?("position: absolute; left: " + Math.floor(this.parent.getClipsByName(selName)[v].itsPort.getPoint().x) + "px; top: " + Math.floor(this.parent.getClipsByName(selName)[v].itsPort.getPoint().y) + "px; "):"") +  "width: " + Math.floor(this.parent.getClipsByName(selName)[v].size.width) + "; height: " + Math.floor(this.parent.getClipsByName(selName)[v].size.height) + "; visibility: " + (vis?SHOW:HIDE) + "; z-index: " + (zindex?zindex:0) + "; \">" + (this.href!=""?("<a href=\"" + this.href + "\" target=\"" + linkTarget + "\">"):"") + (LayerInnerHTML!=""?LayerInnerHTML:"") + (this.hasImage?("<img name=\"" + this.name + "\" src=\"" + this.parent.getClipsByName(selName)[v].itsPort.getObject().itsImg.src + "\" alt=\"" + alt + "\" title=\"" + alt + "\" style=\"border-style: none; border-width: 0px; width: " + this.parent.getClipsByName(selName)[v].size.width + "px; height: " + this.parent.getClipsByName(selName)[v].size.height + "px; \">"):"") + (this.href!=""?"</a>":"") + "</" + (span?"span":(document.layers?"div":"div")) + ">");
			}
		}
		this.parent.defineObjectBinding(this.name, this.name);
	}
	
	
	function balancedRetainedDataFish_getNodes(zindex, linkTarget, clickEvent, doubleClickEvent, innerNodes, itsStyleA, mouseOutEvent, mouseInEvent, alt, span, vis, rel, pak){
		pak=pak?pak:false;
		doubleClickEvent=doubleClickEvent?doubleClickEvent:"";
		clickEvent=clickEvent?clickEvent:"";
		mouseOutEvent=mouseOutEvent!=""?mouseOutEvent:"";
		mouseInEvent=mouseInEvent!=""?mouseInEvent:"";
		linkTarget=linkTarget?linkTarget:"_self";
		span=span?span:false;
		vis=vis?vis:false;
		rel=rel?rel:false;
		innerNodes=innerNodes?innerNodes:null;
		alt=alt?alt:"";
		var islink=this.href!=""?true:false;
		var tmpNode=document.createElement(span?"SPAN":"DIV");
		tmpNode.setAttribute("style", itsStyleA);
		//tmpNode.style.backgroundColor="lightgrey";
		tmpNode.style.zIndex=zindex;
		tmpNode.style.position=rel?"relative":(pak?"fixed":"absolute");
		tmpNode.style.width=Math.floor(this.size.width) + "px";
		tmpNode.style.height=Math.floor(this.size.height) + "px";
		tmpNode.style.left=Math.floor(this.itsPort.getPoint().x) + "px";
		tmpNode.style.top=Math.floor(this.itsPort.getPoint().y) + "px";
		tmpNode.style.visibility=vis?SHOW:HIDE;
		tmpNode.onclick=function(e){e=e?e:event; eval(clickEvent)};
		tmpNode.ondblclick=function(e){e=e?e:event; eval(doubleClickEvent)};
		tmpNode.onmouseover=function(e){e=e?e:event; eval(mouseInEvent)};
		tmpNode.onmouseout=function(e){e=e?e:event; eval(mouseOutEvent)};
		tmpNode.setAttribute("id", this.name);
		tmpNode.setAttribute("name", this.name);
		if(innerNodes!=null) tmpNode.appendChild(innerNodes);
		var tmpANode=document.createElement("A");
		if(this.hasImage){
			var tmpImageNode=document.createElement("IMG");
			tmpImageNode.setAttribute("alt", alt);
			tmpImageNode.setAttribute("title", alt);
			tmpImageNode.style.borderStyle="none";
			tmpImageNode.style.width=Math.floor(this.size.width) + "px";
			tmpImageNode.style.height=Math.floor(this.size.height) + "px";
			tmpImageNode.src=this.itsPort.getObject().itsImg.src;
			tmpImageNode.setAttribute("name", this.name);
			if(this.itsPort.getObject().itsImg.src!="") tmpANode.appendChild(tmpImageNode);
		}
		
		tmpANode.setAttribute("target", linkTarget);
		tmpANode.setAttribute("href", this.href);
		if(islink) tmpNode.appendChild(tmpANode); else
		if(this.hasImage) tmpNode.appendChild(tmpImageNode);
		return tmpNode;
	}

	balancedRetainedDataFish.prototype.setflowAniMode=balancedRetainedDataFish_setflowAniMode;
	balancedRetainedDataFish.prototype.setAnimationMode=balancedRetainedDataFish_setAnimationMode;
	balancedRetainedDataFish.prototype.getHTML=balancedRetainedDataFish_getHTML;
	balancedRetainedDataFish.prototype.write=balancedRetainedDataFish_write;
	balancedRetainedDataFish.prototype.getNodes=balancedRetainedDataFish_getNodes;
	//</BALANCED_RETAINED_DATA_FISH>

	function Fade(selection, selectedIndex, indexStart, indexEnd, fromAlfa, toAlfa, duration, fps, dstArray){
		if(duration>0){//wheter there is an undocked fade
			additionalFishes=Math.round(duration/1000*fps)-(indexEnd-indexStart);
			for(var v=0; v<additionalFishes; v++){
				selection[selectedIndex].push(createDataFish(selection, selection[selectedIndex][indexEnd].name, selection[selectedIndex][indexEnd].id, selection[selectedIndex][indexEnd].itsPort.getPoint().x, selection[selectedIndex][indexEnd].itsPort.getPoint().y, selection[selectedIndex][indexEnd].itsPort.getObject().itsImg.src, selection[selectedIndex][indexEnd].size.width, selection[selectedIndex][indexEnd].size.height, selection[selectedIndex][indexEnd].href, selection[selectedIndex][indexEnd].halign, selection[selectedIndex][indexEnd].valign, selection[selectedIndex][indexEnd].itsPort.getObject().id, -1, dstArray, selection[selectedIndex][indexEnd].hasImage));
			}
		}
		var additionalFishes=0;
		if(duration>0){
			additionalFishes=Math.round(duration/1000*fps)-(indexEnd-indexStart);
		}
		var totalFrames=additionalFishes+(indexEnd-indexStart);
		var perStepOpacityStep=(toAlfa-fromAlfa)/totalFrames;	
		var curOpacity=fromAlfa;
		var perStep;
		if(additionalFishes>0){
			perStep=1000/fps;
		}
		var millis=selection[selectedIndex][indexEnd].millis;
		for(var d=indexStart; d < selection[selectedIndex].length; d++){
			millis+=d>=indexEnd?perStep:-1;
			selection[selectedIndex][d].alfaPercentage=Math.round(curOpacity);
			if(d>indexEnd){
				selection[selectedIndex][d].millis=millis;	
			}
			curOpacity+=perStepOpacityStep;
		}
		return indexEnd+additionalFishes;
	}
	
	function Zoom(selection, selectedIndex, indexStart, indexEnd, relX, relY, slideX, slideY, duration, fps, grab, id, reset, dstArray){
		this.selection=selection;
		this.indexStart=indexStart;
		this.indexEnd=indexEnd;
		if(grab){
			relX=selection[selectedIndex][this.indexEnd].size.width-selection[selectedIndex][this.indexStart].size.width;
			relY=selection[selectedIndex][this.indexEnd].size.height-selection[selectedIndex][this.indexStart].size.height;
		}
		additionalFishes=0;
		this.x=selection[selectedIndex][indexStart].itsPort.getPoint().x;
		this.y=selection[selectedIndex][indexStart].itsPort.getPoint().y;
		this.width=selection[selectedIndex][indexStart].size.width;
		this.height=selection[selectedIndex][indexStart].size.height;
		if(duration>0){//wheter there is an undocked zoom
			additionalFishes=Math.round(duration/1000*fps)-(indexEnd-indexStart);
			for(var v=0; v<additionalFishes; v++){	
				selection[selectedIndex].push(createDataFish(selection, selection[selectedIndex][indexEnd].name, selection[selectedIndex][indexEnd].id, selection[selectedIndex][indexEnd].itsPort.getPoint().x, selection[selectedIndex][indexEnd].itsPort.getPoint().y, selection[selectedIndex][indexEnd].itsPort.getObject().itsImg.src, selection[selectedIndex][indexEnd].size.width, selection[selectedIndex][indexEnd].size.height, selection[selectedIndex][indexEnd].href, selection[selectedIndex][indexEnd].halign, selection[selectedIndex][indexEnd].valign, selection[selectedIndex][indexEnd].itsPort.getObject().id, -1, dstArray, selection[selectedIndex][indexEnd].hasImage));
			}
		}
		var perStep;
		if(additionalFishes>0){
			perStep=1000/fps;
		}
		var millis=!reset?selection[selectedIndex][indexEnd].millis:0;
		var c=additionalFishes>0?(indexEnd)-(indexStart)+additionalFishes:indexEnd-(indexStart);
		this.slideStepX=slideX/c;
		this.slideStepY=slideY/c;
		for(var d=indexStart; d < selection[selectedIndex].length-1; d++){
			millis+=d>=indexEnd?perStep:-1;
			this.resizeNmiddle(relX/c, relY/c, selection[selectedIndex][d], selection[selectedIndex][d+1], duration>0&&d>=indexEnd?millis:false, d>indexEnd?false:true, slideX, slideY);
		}
	}

	function Zoom_resizeNmiddle(relX, relY, dataFishCap, dataFish, millis, docked){//binds to frames per second in case of undocked duration and keeps resolution in other case
			var temp_relY=relY;
			var temp_relX=relX;
			var temp_width=docked?dataFishCap.size.width:this.width;
			var temp_height=docked?dataFishCap.size.height:this.height;
			var temp_x=docked?dataFishCap.itsPort.getPoint().x:this.x;
			var temp_y=docked?dataFishCap.itsPort.getPoint().y:this.y;

			if(dataFish.valign==AlignSet.MIDDLE){
				temp_y=this.y-temp_relY/2+this.slideStepY;
				this.y=temp_y;
			}
			if(dataFish.valign==AlignSet.TOP){
				temp_y=this.y+this.slideStepY;
				this.y=temp_y;
			}
			if(dataFish.valign==AlignSet.BOTTOM){
				temp_y=this.y-temp_relY+this.slideStepY;
				this.y=temp_y;
			}
			if(dataFish.halign==AlignSet.CENTER){
				temp_x=this.x-temp_relX/2+this.slideStepX;
				this.x=temp_x;
			}
			if(dataFish.halign==AlignSet.RIGHT){
				temp_x=this.x-temp_relX+this.slideStepX;
				this.x=temp_x;
			}
			if(dataFish.halign==AlignSet.LEFT){
				temp_x=this.x+this.slideStepX;
				this.x=temp_x;
			}
			//***
			temp_width+=temp_relX;
			temp_height+=temp_relY;
			this.height=temp_height;
			this.width=temp_width;
			millis=millis?millis:false;
			if(millis){
				dataFish.millis=millis?millis:dataFish.millis;
			}
			dataFish.itsPort.getPoint().setX(this.x);
			dataFish.itsPort.getPoint().setY(this.y);
			dataFish.size.width=temp_width;
			dataFish.size.height=temp_height;
			dataFish.itsPort.getObject().indexPositioningId=Math.random()*1000 + Math.random()*1000000 + Math.random()*10000000000;
	}

	Zoom.prototype.resizeNmiddle=Zoom_resizeNmiddle;
	
	function Move(selection, selectedIndex, indexStart, indexEnd, a_zoomX, a_zoomY, slideX, slideY, duration, fps, grab, id, reset, dstArray){
		this.selection=selection;
		this.indexStart=indexStart;
		this.indexEnd=indexEnd;
		if(grab){
			a_zoomX=(selection[selectedIndex][this.indexEnd].size.width)/(selection[selectedIndex][this.indexStart].size.width);
			a_zoomY=(selection[selectedIndex][this.indexEnd].size.height)/(selection[selectedIndex][this.indexStart].size.height);
		}
		additionalFishes=0;
		this.x=0;
		//selection[selectedIndex][indexStart].itsPort.getPoint().x;
		this.y=0;
		//selection[selectedIndex][indexStart].itsPort.getPoint().y;
		this.width=selection[selectedIndex][indexStart].size.width;
		this.height=selection[selectedIndex][indexStart].size.height;
		if(duration>0){//wheter there is an undocked zoom
			additionalFishes=Math.round(duration/1000*fps)-(indexEnd-indexStart);
			for(var v=0; v<additionalFishes; v++){	
				selection[selectedIndex].push(createDataFish(selection, selection[selectedIndex][indexEnd].name, selection[selectedIndex][indexEnd].id, selection[selectedIndex][indexEnd].itsPort.getPoint().x, selection[selectedIndex][indexEnd].itsPort.getPoint().y, selection[selectedIndex][indexEnd].itsPort.getObject().itsImg.src, selection[selectedIndex][indexEnd].size.width, selection[selectedIndex][indexEnd].size.height, selection[selectedIndex][indexEnd].href, selection[selectedIndex][indexEnd].halign, selection[selectedIndex][indexEnd].valign, selection[selectedIndex][indexEnd].itsPort.getObject().id, -1, dstArray, selection[selectedIndex][indexEnd].hasImage));
			}
		}
		var perStep;
		if(additionalFishes>0){
			perStep=1000/fps;
		}
		var millis=!reset?selection[selectedIndex][indexEnd].millis:0;
		var c=additionalFishes>0?(indexEnd)-(indexStart)+additionalFishes:indexEnd-(indexStart);
		this.slideStepX=slideX/c;
		this.slideStepY=slideY/c;
		for(var d=indexStart; d < selection[selectedIndex].length-1; d++){
			millis+=d>=indexEnd?perStep:-1;
			this.moveNmiddle(a_zoomX, a_zoomY, selection[selectedIndex][d], selection[selectedIndex][d+1], duration>0&&d>=indexEnd?millis:false, d>indexEnd?false:true);
		}
	}
	
	
	function Move_moveNmiddle(a_zoomX, a_zoomY, dataFishCap, dataFish, millis, docked){//binds to frames per second in case of undocked duration and keeps resolution in other case
		var temp_relY=dataFish.size.height-dataFish.size.height*a_zoomY;
		var temp_relX=dataFish.size.width-dataFish.size.width*a_zoomX;
		var temp_width=dataFish.size.width;
		var temp_height=dataFish.size.height;
		var temp_x=docked?dataFishCap.itsPort.getPoint().x:this.x;
		var temp_y=docked?dataFishCap.itsPort.getPoint().y:this.y;

		if(dataFish.valign==AlignSet.MIDDLE){
			temp_y=this.y-temp_relY/2+this.slideStepY;
			this.y=temp_y;
		}
		if(dataFish.valign==AlignSet.TOP){
			temp_y=this.y+this.slideStepY;
			this.y=temp_y;
		}
		if(dataFish.valign==AlignSet.BOTTOM){
			temp_y=this.y-temp_relY+this.slideStepY;
			this.y=temp_y;
		}
		if(dataFish.halign==AlignSet.CENTER){
			temp_x=this.x-temp_relX/2+this.slideStepX;
			this.x=temp_x;
		}
		if(dataFish.halign==AlignSet.RIGHT){
			temp_x=this.x-temp_relX+this.slideStepX;
			this.x=temp_x;
		}
		if(dataFish.halign==AlignSet.LEFT){
			temp_x=this.x+this.slideStepX;
			this.x=temp_x;
		}
		//***
		temp_width+=temp_relX;
		temp_height+=temp_relY;
		this.height=temp_height;
		this.width=temp_width;
		millis=millis?millis:false;
		if(millis){
			dataFish.millis=millis?millis:dataFish.millis;
		}
		dataFish.itsPort.getPoint().setX(Math.round(dataFish.itsPort.getPoint().getX()+this.x));
		dataFish.itsPort.getPoint().setY(Math.round(dataFish.itsPort.getPoint().getY()+this.y));
		dataFish.size.width=a_zoomX>=1?Math.floor(temp_width):Math.ceil(temp_width);
		dataFish.size.height=a_zoomY>=1?Math.floor(temp_height):Math.ceil(temp_height);
		dataFish.itsPort.getObject().indexPositioningId=Math.random()*1000 + Math.random()*1000000 + Math.random()*10000000000;
	}
	
	Move.prototype.moveNmiddle=Move_moveNmiddle;