/*
Copyright �2009-2010 Daniel Wiesen�cker

    
    This file is part of TschuggiFader.

    Ttschuggi Fader is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    TschuggiFader is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with TschuggiFader.  If not, see <http://www.gnu.org/licenses/>.

*/
	var ctrl=unescape("%" + int2hex(21));
	var ctrl2=unescape("%" + int2hex(20));
	
function int2char(num){
	switch(str2int(num)){
		case 1:
			return '?';
		break;
		case 2:
			return '?';
		break;
		case 3:
			return '?';
		break;
		case 4:
			return '?';
		break;
		case 5:
			return '?';
		break;
		case 6:
			return '?';
		break;
		case 7:
			return '?';
		break;
		case 8:
			return '?';
		break;
		case 9:
			return '?';
		break;
		case 10:
			return '?';
		break;
		case 11:
			return '?';
		break;
		case 12:
			return '?';
		break;
		case 13:
			return '?';
		break;
		case 14:
			return '?';
		break;
		case 15:
			return '?';
		break;
		case 16:
			return '?';
		break;
		case 17:
			return '?';
		break;
		case 18:
			return '?';
		break;
		case 19:
			return '?';
		break;
		case 20:
			return ctrl2;
		break;
		case 21:
			return ctrl;
		break;
		case 22:
			return "?";
		break;
		case 23:
			return '?';
		break;
		case 24:
			return '?';
		break;
		case 25:
			return '?';
		break;
		case 26:
			return '?';
		break;
		case 27:
			return '?';
		break;
		case 28:
			return '?';
		break;
		case 29:
			return '?';
		break;
		case 30:
			return '?';
		break;
		case 31:
			return '?';
		break;
		case 32:
			return ' ';
		break;
		case 33:
			return '!';
		break;
		case 34:
			return '"';
		break;
		case 35:
			return '#';
		break;
		case 36:
			return '$';
		break;
		case 37:
			return '%';
		break;
		case 38:
			return '&';
		break;
		case 39:
			return "'";
		break;
		case 40:
			return '(';
		break;
		case 41:
			return ')';
		break;
		case 42:
			return '*';
		break;
		case 43:
			return '+';
		break;
		case 44:
			return ',';
		break;
		case 45:
			return '-';
		break;
		case 46:
			return '.';
		break;
		case 47:
			return '/';
		break;
		case 48:
			return '0';
		break;
		case 49:
			return '1';
		break;
		case 50:
			return '2';
		break;
		case 51:
			return '3';
		break;
		case 52:
			return '4';
		break;
		case 53:
			return '5';
		break;
		case 54:
			return '6';
		break;
		case 55:
			return '7';
		break;
		case 56:
			return '8';
		break;
		case 57:
			return '9';
		break;
		case 58:
			return ':';
		break;
		case 59:
			return ';';
		break;
		case 60:
			return '<';
		break;
		case 61:
			return '=';
		break;
		case 62:
			return '>';
		break;
		case 63:
			return '?';
		break;
		case 64:
			return '@';
		break;
		case 65:
			return 'A';
		break;
		case 66:
			return 'B';
		break;
		case 67:
			return 'C';
		break;
		case 68:
			return 'D';
		break;
		case 69:
			return 'E';
		break;
		case 70:
			return 'F';
		break;
		case 71:
			return 'G';
		break;
		case 72:
			return 'H';
		break;
		case 73:
			return 'I';
		break;
		case 74:
			return 'J';
		break;
		case 75:
			return 'K';
		break;
		case 76:
			return 'L';
		break;
		case 77:
			return 'M';
		break;
		case 78:
			return 'N';
		break;
		case 79:
			return 'O';
		break;
		case 80:
			return 'P';
		break;
		case 81:
			return 'Q';
		break;
		case 82:
			return 'R';
		break;
		case 83:
			return 'S';
		break;
		case 84:
			return 'T';
		break;
		case 85:
			return 'U';
		break;
		case 86:
			return 'V';
		break;
		case 87:
			return 'W';
		break;
		case 88:
			return 'X';
		break;
		case 89:
			return 'Y';
		break;
		case 90:
			return 'Z';
		break;
		case 91:
			return '[';
		break;
		case 92:
			return '\\';
		break;
		case 93:
			return ']';
		break;
		case 94:
			return '^';
		break;
		case 95:
			return '_';
		break;
		case 96:
			return '`';
		break;
		case 97:
			return 'a';
		break;
		case 98:
			return 'b';
		break;
		case 99:
			return 'c';
		break;
		case 100:
			return 'd';
		break;
		case 101:
			return 'e';
		break;
		case 102:
			return 'f';
		break;
		case 103:
			return 'g';
		break;
		case 104:
			return 'h';
		break;
		case 105:
			return 'i';
		break;
		case 106:
			return 'j';
		break;
		case 107:
			return 'k';
		break;
		case 108:
			return 'l';
		break;
		case 109:
			return 'm';
		break;
		case 110:
			return 'n';
		break;
		case 111:
			return 'o';
		break;
		case 112:
			return 'p';
		break;
		case 113:
			return 'q';
		break;
		case 114:
			return 'r';
		break;
		case 115:
			return 's';
		break;
		case 116:
			return 't';
		break;
		case 117:
			return 'u';
		break;
		case 118:
			return 'v';
		break;
		case 119:
			return 'w';
		break;
		case 120:
			return 'x';
		break;
		case 121:
			return 'y';
		break;
		case 122:
			return 'z';
		break;
		case 123:
			return '{';
		break;
		case 124:
			return '|';
		break;
		case 125:
			return '}';
		break;
		case 126:
			return '~';
		break;
		case 127:
			return '?';
		break;
		case 128:
			return '�';
		break;
		case 129:
			return '�';
		break;
		case 130:
			return '�';
		break;
		case 131:
			return '�';
		break;
		case 132:
			return '�';
		break;
		case 133:
			return '�';
		break;
		case 134:
			return '�';
		break;
		case 135:
			return '�';
		break;
		case 136:
			return '�';
		break;
		case 137:
			return '�';
		break;
		case 138:
			return '�';
		break;
		case 139:
			return '�';
		break;
		case 140:
			return '�';
		break;
		case 141:
			return '�';
		break;
		case 142:
			return '�';
		break;
		case 143:
			return '�';
		break;
		case 144:
			return '�';
		break;
		case 145:
			return '�';
		break;
		case 146:
			return '�';
		break;
		case 147:
			return '�';
		break;
		case 148:
			return '�';
		break;
		case 149:
			return '�';
		break;
		case 150:
			return '�';
		break;
		case 151:
			return '�';
		break;
		case 152:
			return '�';
		break;
		case 153:
			return '�';
		break;
		case 154:
			return '�';
		break;
		case 155:
			return '�';
		break;
		case 156:
			return '�';
		break;
		case 157:
			return '�';
		break;
		case 158:
			return '�';
		break;
		case 159:
			return '?';
		break;
		case 160:
			return '�';
		break;
		case 161:
			return '�';
		break;
		case 162:
			return '�';
		break;
		case 163:
			return '�';
		break;
		case 164:
			return '�';
		break;
		case 165:
			return '�';
		break;
		case 166:
			return '�';
		break;
		case 167:
			return '�';
		break;
		case 168:
			return '�';
		break;
		case 169:
			return '�';
		break;
		case 170:
			return '�';
		break;
		case 171:
			return '�';
		break;
		case 172:
			return '�';
		break;
		case 173:
			return '�';
		break;
		case 174:
			return '�';
		break;
		case 175:
			return '�';
		break;
		case 176:
			return '?';
		break;
		case 177:
			return '?';
		break;
		case 178:
			return '?';
		break;
		case 179:
			return '?';
		break;
		case 180:
			return '?';
		break;
		case 181:
			return '�';
		break;
		case 182:
			return '�';
		break;
		case 183:
			return '�';
		break;
		case 184:
			return '�';
		break;
		case 185:
			return '?';
		break;
		case 186:
			return '?';
		break;
		case 187:
			return '?';
		break;
		case 188:
			return '?';
		break;
		case 189:
			return '�';
		break;
		case 190:
			return '�';
		break;
		case 191:
			return '?';
		break;
		case 192:
			return '?';
		break;
		case 193:
			return '?';
		break;
		case 194:
			return '?';
		break;
		case 195:
			return '?';
		break;
		case 196:
			return '?';
		break;
		case 197:
			return '?';
		break;
		case 198:
			return '�';
		break;
		case 199:
			return '�';
		break;
		case 200:
			return '?';
		break;
		case 201:
			return '?';
		break;
		case 202:
			return '?';
		break;
		case 203:
			return '?';
		break;
		case 204:
			return '?';
		break;
		case 205:
			return '?';
		break;
		case 206:
			return '?';
		break;
		case 207:
			return '�';
		break;
		case 208:
			return '�';
		break;
		case 209:
			return '�';
		break;
		case 210:
			return '�';
		break;
		case 211:
			return '�';
		break;
		case 212:
			return '�';
		break;
		case 213:
			return '?';
		break;
		case 214:
			return '�';
		break;
		case 215:
			return '�';
		break;
		case 216:
			return '�';
		break;
		case 217:
			return '?';
		break;
		case 218:
			return '?';
		break;
		case 219:
			return '?';
		break;
		case 220:
			return '?';
		break;
		case 221:
			return '�';
		break;
		case 222:
			return '�';
		break;
		case 223:
			return '?';
		break;
		case 224:
			return '�';
		break;
		case 225:
			return '�';
		break;
		case 226:
			return '�';
		break;
		case 227:
			return '�';
		break;
		case 228:
			return '�';
		break;
		case 229:
			return '�';
		break;
		case 230:
			return '�';
		break;
		case 231:
			return '�';
		break;
		case 232:
			return '�';
		break;
		case 233:
			return '�';
		break;
		case 234:
			return '�';
		break;
		case 235:
			return '�';
		break;
		case 236:
			return '�';
		break;
		case 237:
			return '�';
		break;
		case 238:
			return '�';
		break;
		case 239:
			return '�';
		break;
		case 240:
			return '�';
		break;
		case 241:
			return '�';
		break;
		case 242:
			return '?';
		break;
		case 243:
			return '�';
		break;
		case 244:
			return "�";
		break;
		case 245:
			return '�';
		break;
		case 246:
			return '�';
		break;
		case 247:
			return '�';
		break;
		case 248:
			return '�';
		break;
		case 249:
			return '�';
		break;
		case 250:
			return '�';
		break;
		case 251:
			return '�';
		break;
		case 252:
			return '�';
		break;
		case 253:
			return '�';
		break;
		case 254:
			return '?';
		break;
		case 255:
			return '�';
		}
}
	
function asciiValue(schar){

	switch(schar){
		case '?':
			return 1;
		break;
		case '?':
			return 2;
		break;
		case '?':
			return 3;
		break;
		case '?':
			return 4;
		break;
		case '?':
			return 5;
		break;
		case '?':
			return 6;
		break;
		case '?':
			return 7;
		break;
		case '?':
			return 8;
		break;
		case '?':
			return 9;
		break;
		case '?':
			return 10;
		break;
		case '?':
			return 11;
		break;
		case '?':
			return 12;
		break;
		case '?':
			return 13;
		break;
		case '?':
			return 14;
		break;
		case '?':
			return 15;
		break;
		case '?':
			return 16;
		break;
		case '?':
			return 17;
		break;
		case '?':
			return 18;
		break;
		case '?':
			return 19;
		break;
		case ctrl2:
			return 20;
		break;
		case ctrl:
			return 21;
		break;
		case '?':
			return 22;
		break;
		case '?':
			return 23;
		break;
		case '?':
			return 24;
		break;
		case '?':
			return 25;
		break;
		case '?':
			return 26;
		break;
		case '?':
			return 27;
		break;
		case '?':
			return 28;
		break;
		case '?':
			return 29;
		break;
		case '?':
			return 30;
		break;
		case '?':
			return 31;
		break;
		case ' ':
			return 32;
		break;
		case '!':
			return 33;
		break;
		case '"':
			return 34;
		break;
		case '#':
			return 35;
		break;
		case '$':
			return 36;
		break;
		case '%':
			return 37;
		break;
		case '&':
			return 38;
		break;
		case "'":
			return 39;
		break;
		case '(':
			return 40;
		break;
		case ')':
			return 41;
		break;
		case '*':
			return 42;
		break;
		case '+':
			return 43;
		break;
		case ',':
			return 44;
		break;
		case '-':
			return 45;
		break;
		case '.':
			return 46;
		break;
		case '/':
			return 47;
		break;
		case '0':
			return 48;
		break;
		case '1':
			return 49;
		break;
		case '2':
			return 50;
		break;
		case '3':
			return 51;
		break;
		case '4':
			return 52;
		break;
		case '5':
			return 53;
		break;
		case '6':
			return 54;
		break;
		case '7':
			return 55;
		break;
		case '8':
			return 56;
		break;
		case '9':
			return 57;
		break;
		case ':':
			return 58;
		break;
		case ';':
			return 59;
		break;
		case '<':
			return 60;
		break;
		case '=':
			return 61;
		break;
		case '>':
			return 62;
		break;
		case '?':
			return 63;
		break;
		case '@':
			return 64;
		break;
		case 'A':
			return 65;
		break;
		case 'B':
			return 66;
		break;
		case 'C':
			return 67;
		break;
		case 'D':
			return 68;
		break;
		case 'E':
			return 69;
		break;
		case 'F':
			return 70;
		break;
		case 'G':
			return 71;
		break;
		case 'H':
			return 72;
		break;
		case 'I':
			return 73;
		break;
		case 'J':
			return 74;
		break;
		case 'K':
			return 75;
		break;
		case 'L':
			return 76;
		break;
		case 'M':
			return 77;
		break;
		case 'N':
			return 78;
		break;
		case 'O':
			return 79;
		break;
		case 'P':
			return 80;
		break;
		case 'Q':
			return 81;
		break;
		case 'R':
			return 82;
		break;
		case 'S':
			return 83;
		break;
		case 'T':
			return 84;
		break;
		case 'U':
			return 85;
		break;
		case 'V':
			return 86;
		break;
		case 'W':
			return 87;
		break;
		case 'X':
			return 88;
		break;
		case 'Y':
			return 89;
		break;
		case 'Z':
			return 90;
		break;
		case '[':
			return 91;
		break;
		case '\\':
			return 92;
		break;
		case ']':
			return 93;
		break;
		case '^':
			return 94;
		break;
		case '_':
			return 95;
		break;
		case '`':
			return 96;
		break;
		case 'a':
			return 97;
		break;
		case 'b':
			return 98;
		break;
		case 'c':
			return 99;
		break;
		case 'd':
			return 100;
		break;
		case 'e':
			return 101;
		break;
		case 'f':
			return 102;
		break;
		case 'g':
			return 103;
		break;
		case 'h':
			return 104;
		break;
		case 'i':
			return 105;
		break;
		case 'j':
			return 106;
		break;
		case 'k':
			return 107;
		break;
		case 'l':
			return 108;
		break;
		case 'm':
			return 109;
		break;
		case 'n':
			return 110;
		break;
		case 'o':
			return 111;
		break;
		case 'p':
			return 112;
		break;
		case 'q':
			return 113;
		break;
		case 'r':
			return 114;
		break;
		case 's':
			return 115;
		break;
		case 't':
			return 116;
		break;
		case 'u':
			return 117;
		break;
		case 'v':
			return 118;
		break;
		case 'w':
			return 119;
		break;
		case 'x':
			return 120;
		break;
		case 'y':
			return 121;
		break;
		case 'z':
			return 122;
		break;
		case '{':
			return 123;
		break;
		case '|':
			return 124;
		break;
		case '}':
			return 125;
		break;
		case '~':
			return 126;
		break;
		case '?':
			return 127;
		break;
		case '�':
			return 128;
		break;
		case '�':
			return 129;
		break;
		case '�':
			return 130;
		break;
		case '�':
			return 131;
		break;
		case '�':
			return 132;
		break;
		case '�':
			return 133;
		break;
		case '�':
			return 134;
		break;
		case '�':
			return 135;
		break;
		case '�':
			return 136;
		break;
		case '�':
			return 137;
		break;
		case '�':
			return 138;
		break;
		case '�':
			return 139;
		break;
		case '�':
			return 140;
		break;
		case '�':
			return 141;
		break;
		case '�':
			return 142;
		break;
		case '�':
			return 143;
		break;
		case '�':
			return 144;
		break;
		case '�':
			return 145;
		break;
		case '�':
			return 146;
		break;
		case '�':
			return 147;
		break;
		case '�':
			return 148;
		break;
		case '�':
			return 149;
		break;
		case '�':
			return 150;
		break;
		case '�':
			return 151;
		break;
		case '�':
			return 152;
		break;
		case '�':
			return 153;
		break;
		case '�':
			return 154;
		break;
		case '�':
			return 155;
		break;
		case '�':
			return 156;
		break;
		case '�':
			return 157;
		break;
		case '�':
			return 158;
		break;
		case '?':
			return 159;
		break;
		case '�':
			return 160;
		break;
		case '�':
			return 161;
		break;
		case '�':
			return 162;
		break;
		case '�':
			return 163;
		break;
		case '�':
			return 164;
		break;
		case '�':
			return 165;
		break;
		case '�':
			return 166;
		break;
		case '�':
			return 167;
		break;
		case '�':
			return 168;
		break;
		case '�':
			return 169;
		break;
		case '�':
			return 170;
		break;
		case '�':
			return 171;
		break;
		case '�':
			return 172;
		break;
		case '�':
			return 173;
		break;
		case '�':
			return 174;
		break;
		case '�':
			return 175;
		break;
		case '?':
			return 176;
		break;
		case '?':
			return 177;
		break;
		case '?':
			return 178;
		break;
		case '?':
			return 179;
		break;
		case '?':
			return 180;
		break;
		case '�':
			return 181;
		break;
		case '�':
			return 182;
		break;
		case '�':
			return 183;
		break;
		case '�':
			return 184;
		break;
		case '?':
			return 185;
		break;
		case '?':
			return 186;
		break;
		case '?':
			return 187;
		break;
		case '?':
			return 188;
		break;
		case '�':
			return 189;
		break;
		case '�':
			return 190;
		break;
		case '?':
			return 191;
		break;
		case '?':
			return 192;
		break;
		case '?':
			return 193;
		break;
		case '?':
			return 194;
		break;
		case '?':
			return 195;
		break;
		case '?':
			return 196;
		break;
		case '?':
			return 197;
		break;
		case '�':
			return 198;
		break;
		case '�':
			return 199;
		break;
		case '?':
			return 200;
		break;
		case '?':
			return 201;
		break;
		case '?':
			return 202;
		break;
		case '?':
			return 203;
		break;
		case '?':
			return 204;
		break;
		case '?':
			return 205;
		break;
		case '?':
			return 206;
		break;
		case '�':
			return 207;
		break;
		case '�':
			return 208;
		break;
		case '�':
			return 209;
		break;
		case '�':
			return 210;
		break;
		case '�':
			return 211;
		break;
		case '�':
			return 212;
		break;
		case '?':
			return 213;
		break;
		case '�':
			return 214;
		break;
		case '�':
			return 215;
		break;
		case '�':
			return 216;
		break;
		case '?':
			return 217;
		break;
		case '?':
			return 218;
		break;
		case '?':
			return 219;
		break;
		case '?':
			return 220;
		break;
		case '�':
			return 221;
		break;
		case '�':
			return 222;
		break;
		case '?':
			return 223;
		break;
		case '�':
			return 224;
		break;
		case '�':
			return 225;
		break;
		case '�':
			return 226;
		break;
		case '�':
			return 227;
		break;
		case '�':
			return 228;
		break;
		case '�':
			return 229;
		break;
		case '�':
			return 230;
		break;
		case '�':
			return 231;
		break;
		case '�':
			return 232;
		break;
		case '�':
			return 233;
		break;
		case '�':
			return 234;
		break;
		case '�':
			return 235;
		break;
		case '�':
			return 236;
		break;
		case '�':
			return 237;
		break;
		case '�':
			return 238;
		break;
		case '�':
			return 239;
		break;
		case '�':
			return 240;
		break;
		case '�':
			return 241;
		break;
		case '?':
			return 242;
		break;
		case '�':
			return 243;
		break;
		case '�':
			return 244;
		break;
		case '�':
			return 245;
		break;
		case '�':
			return 246;
		break;
		case '�':
			return 247;
		break;
		case '�':
			return 248;
		break;
		case '�':
			return 249;
		break;
		case '�':
			return 250;
		break;
		case '�':
			return 251;
		break;
		case '�':
			return 252;
		break;
		case '�':
			return 253;
		break;
		case '?':
			return 254;
		break;
		case '�':
			return 255;
		}
	return -1;
}


	function zerofill(it, decimals){
		astr="" + it;
		while(astr.length<decimals){
			astr="0" + astr;
		}
		return astr;
	}

	function str2int(astr){
		return -1*-1*(astr);
	}

	function int2hex(aint){
		hexInt = new Array();
		v=0;
		while( aint > 0){
			hexInt[v] = aint % 16;
			aint = Math.floor(aint / 16);
			v++;
		}
		hex="";
		for(v=(hexInt.length-1); v >= 0 ; v--){
			switch(hexInt[v]){
				case 10:
					hex+='A';
				break;
				case 11:
					hex+='B';
				break;
				case 12:
					hex+='C';
				break;
				case 13:
					hex+='D';
				break;
				case 14:
					hex+='E';
				break;
				case 15:
					hex+='F';
				break;
				default:
					hex+=""  + hexInt[v];
			}
		}
		return hex;
	}

	function hex2int(hexstr){
		val = new Array();
		for(v=0; v < hexstr.length; v++){
			switch(hexstr.substr(v, 1)){
				case 'A':
				case 'a':
					val[v]=10;
				break;
				case 'B':
				case 'b':
					val[v]=11;
				break;
				case 'C':
				case 'c':
					val[v]=12;
				break;
				case 'D':
				case 'd':
					val[v]=13;
				break;
				case 'E':
				case 'e':
					val[v]=14;
				break;
				case 'F':
				case 'f':
					val[v]=15;
				break;
				default:
					val[v]=str2int(hexstr.substr(v, 1));
			}
		}
		value=1;
		retval=0;
		for(v=val.length-1; v >= 0 ; v--){
			retval+=val[v]*value;
			value=value*16;
		}
		return retval;
	}

    function char2ByteHex(character){ //liefert 2 hex zu ascii integer
        switch(character){
            case '0': value="%30";
            break;
            case '1': value="%31";
            break;
            case '2': value="%32";
            break;
            case '3': value="%33";
            break;
            case '4': value="%34";
            break;
            case '5': value="%35";
            break;
            case '6': valze="%36";
            break;
            case '7': value="%37";
            break;
            case '8': value="%38";
            break;
            case '9': value="%39";
            break;
            case 'A': value="%41";
            break;
            case 'B': value="%42";
            break;
            case 'C': value="%43";
            break;
            case 'D': value="%44";
            break;
            case 'E': value="%45";
            break;
            case 'F': value="%46";
            break;
            case 'G': value="%47";
            break;
            case 'H': value="%48";
            break;
            case 'I': value="%49";
            break;
            case 'J': value="%4a";
            break;
            case 'K': value="%4b";
            break;
            case 'L': value="%4c";
            break;
            case 'M': value="%4d";
            break;
            case 'N': value="%4e";
            break;
            case 'O': value="%4f";
            break;
            case 'P': value="%50";
            break;
            case 'Q': value="%51";
            break;
            case 'R': value="%52";
            break;
            case 'S': value="%53";
            break;
            case 'T': value="%54";
            break;
            case 'U': value="%55";
            break;
            case 'V': value="%56";
            break;
            case 'W': value="%57";
            break;
            case 'X': value="%58";
            break;
            case 'Y': value="%59";
            break;
            case 'Z': value="%5a";
            break;
            case 'a': value="%61";
            break;
            case 'b': value="%62";
            break;
            case 'c': value="%63";
            break;
            case 'd': value="%64";
            break;
            case 'e': value="%65";
            break;
            case 'f': value="%66";
            break;
            case 'g': value="%67";
            break;
            case 'h': value="%68";
            break;
            case 'i': value="%69";
            break;
            case 'j': value="%6a";
            break;
            case 'k': value="%6b";
            break;
            case 'l': value="%6c";
            break;
            case 'm': value="%6d";
            break;
            case 'n': value="%6e";
            break;
            case 'o': value="%6f";
            break;
            case 'p': value="%70";
            break;
            case 'q': value="%71";
            break;
            case 'r': value="%72";
            break;
            case 's': value="%73";
            break;
            case 't': value="%74";
            break;
            case 'u': value="%75";
            break;
            case 'v': value="%76";
            break;
            case 'w': value="%77";
            break;
            case 'x': value="%78";
            break;
            case 'y': value="%79";
            break;
            case 'z': value="%7a";
            default: value = escape(character);
        }
        return value.substr(1,2);
    }

function greaterOrEqual(str1, str2){
	pos=0;
	if(str1.length<str2.length){
		return false;
	}
	if(str1.length>str2.length){
		return true;
	}
	if(str1.length==str2.length){
		while(pos<str1.length&&pos<str2.length){
			if(str1.substr(pos,1)<str2.substr(pos,1)){
				return false;
			}
			pos++;
		}
	return true;
	}

}