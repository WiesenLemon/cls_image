<?php
	error_reporting(E_ERROR);
	ini_set('display_errors', FALSE);
	//error_reporting(E_ALL);
	//ini_set('display_errors', TRUE);
?>
	var MainCategories= new Array();

<?php
	$a=0;
	$items[$a]="Artikel";
?>

	MainCategories[0] = new Array();

	MainCategories[0][0]="4";

<?php
	echo "MainCategories[" . $a . "][1]=\"" . $items[$a++] . "\";";
?>

	MainCategories[0][2]="http://localhost";

	MainCategories[0][3]="_new";

	MainCategories[0][4]="Artikel erstellen, bearbeiten, freigeben, illustrieren oder l&ouml;schen";

	MainCategories[0][5]="0";



<?php
	$items[$a]="Illustrationen";
?>


	MainCategories[1] = new Array();

	MainCategories[1][0]="4";

<?php
	echo "MainCategories[" . $a . "][1]=\"" . $items[$a++] . "\";";
?>

	MainCategories[1][2]="http://localhost";

	MainCategories[1][3]="_new";

	MainCategories[1][4]="Bilder bewerten, kommentieren und einpflegen";

	MainCategories[1][5]="1";



<?php
	$items[$a]="Bewertungen";
?>

	MainCategories[2] = new Array();

	MainCategories[2][0]="4";

<?php
	echo "MainCategories[" . $a . "][1]=\"" . $items[$a++] . "\";";
?>

	MainCategories[2][2]="http://localhost";

	MainCategories[2][3]="_new";

	MainCategories[2][4]="Ratings lesen, Statistik einsehen";

	MainCategories[2][5]="2";


<?php
	$items[$a]="Ausgaben";
?>

	
	MainCategories[3] = new Array();

	MainCategories[3][0]="4";

<?php
	echo "MainCategories[" . $a . "][1]=\"" . $items[$a++] . "\";";
?>

	MainCategories[3][2]="http://localhost";

	MainCategories[3][3]="_new";

	MainCategories[3][4]="Ratings lesen, Statistik einsehen";

	MainCategories[3][5]="3";

	
<?php
?>